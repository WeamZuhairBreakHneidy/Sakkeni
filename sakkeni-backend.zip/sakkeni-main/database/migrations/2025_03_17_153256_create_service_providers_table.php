<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('service_providers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')
            ->constrained('users') 
            ->cascadeOnDelete()
            ->cascadeOnUpdate();
            $table->float('rate')->default(0.00);
            $table->integer('num_of_rating')->default(0);
            $table->string('description')->nullable();
            $table->string('status')->default('pending_approval');
            $table->foreignId('pending_subscription_plan_id')->nullable()->constrained('subscription_plans');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('service_providers');
    }
};
