# Sakkeni Graduation Project
An innovative platform streamlining real estate management with comprehensive technical services, enhancing efficiency and connectivity for property owners, tenants, and service providers through seamless integration and user-friendly interfaces.

Technology Stack & Architecture:
+ Implements core business logic, data access, and API endpoints.

+ Aspect-Oriented Programming (AOP) is utilized to handle cross-cutting concerns such as Tracing, ensuring clean and maintainable code.

Architecture:
+ 3-tier (Presentation, Business Logic, Data Access)
